Put the free Piper TTS voice models here; see SKILL.md, "Voices".
